package steps;

import java.io.File;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident {
	public static String sys_id;
	public static RequestSpecification inputRequest;
	public static Response response;
	public static String number;
	@Given ("setup baseURI")
	public void setup()
	{
		RestAssured.baseURI="https://dev123161.service-now.com/api/now/table/incident";
		
	}
	@And("validate credentials")
	public void credential()
	{
		RestAssured.authentication = RestAssured.basic("admin","Kajal@123");
	}
	@When("create incident with {string}")
	public void postWithBody(String fileName)
	{
		File inputFile = new File("./src/main/resources/"+fileName);
		inputRequest = RestAssured.given().contentType("application/json");
		
		response= inputRequest.when().body(inputFile).post();
	}
	@Then("status code is {int}")
	public void verifyStatusCode(int statusCode)
	{
		response = response.then().assertThat().statusCode(statusCode).extract().response();
	}
	@When("get Incident with key {string} and value {string}")
	public void queryParam(String key,String value)
	{
		response = RestAssured.given().queryParam(key,value).when().get();
				
	}
	@Then("Status code is {int}")
	public void verifyGetStatusCode(int statusCode)
	{
		response.then().assertThat().statusCode(statusCode);
		System.out.println("The status code for getstatusCode: " + statusCode);
		
	}
	@When("update Incident with {string}")
	public void updateInc(String file)
	{
		File inputFile = new File("./src/main/resources/" +file);
		inputRequest = RestAssured.given().contentType("application/json");
		response= inputRequest.when().body(inputFile).put(sys_id);
	}
	@Then("Status code {int}")
	public void UpdateStatusCode(int statusCode) {
		response.then().assertThat().statusCode(statusCode);
		System.out.println("The status code for updatestatusCode: " + statusCode);
	}
	@When("get Incident by sysid")
	public void get() {
	//inputRequest = RestAssured.given().contentType("application/json");
		sys_id = response.jsonPath().get("result.sys_id");
	response = RestAssured.get("/" +sys_id);
	response.prettyPrint();
	System.out.println("The Sysid is:" +sys_id);
	}
	@When("Delete an Incident")
	public void deleteInc()
	{
		inputRequest = RestAssured.given().contentType("application/json");
		response = inputRequest.delete(sys_id);
		
	}
	@Then("The Status Code is {int}")
	public void deleteStatusCode(int statusCode)
	{
		response.then().assertThat().statusCode(statusCode);
		System.out.println("The statsu code for delete: " + statusCode);
	}
			
}

package steps;

import java.io.File;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class jiraissues {
	public static String issueId;
	public static RequestSpecification inputRequest;
	public static Response response;
	public static String summary;
	@Given ("setup baseURI")
	public void setup()
	{
		RestAssured.baseURI="https://learningrestapitestleaf.atlassian.net/rest/api/2/issue/";
		
		
	}
	@And("validate credentials")
	public void credential()
	{
		RestAssured.authentication = RestAssured.preemptive().basic("kavithapremraj@outlook.com","gq7fBQ3C3F5BO4bI6ZUf1DDE");
	}
	@When("create jira with {string}")
	public void postWithBody(String fileName)
	{
		File inputFile = new File("./src/main/resources/"+fileName);
		inputRequest = RestAssured.given().contentType("application/json");
		response= inputRequest.when().body(inputFile).post();
		issueId = response.jsonPath().get("id");
		System.out.println("The Captured id is: " +issueId);
		/*
		 * summary = response.jsonPath().get("fields.summary");
		 * System.out.println(summary);
		 */
		
		
	}
	@Then("status code is {int}")
	public void verifyStatusCode(int statusCode)
	{
		response = response.then().assertThat().statusCode(statusCode).extract().response();
	}
	@When("get jira by issueid")
	public void issueId()
	{
		inputRequest = RestAssured.given().contentType("application/json");
		response= inputRequest.get(issueId);
		/*
		 * summary = response.jsonPath().get("fields.summary");
		 * System.out.println(summary);
		 */
				
	}
	@Then("Status code is {int}")
	public void verifyGetStatusCode(int statusCode)
	{
		response.then().assertThat().statusCode(statusCode);
		System.out.println("The status code for getstatusCode: " + statusCode);
		
	}
	@When("update jira with {string}")
	public void updateInc(String file)
	{
		File inputFile = new File("./src/main/resources/" +file);
		inputRequest = RestAssured.given().contentType("application/json");
		response= inputRequest.when().body(inputFile).put(issueId);
	}
	@Then("Status code {int}")
	public void UpdateStatusCode(int statusCode) {
		response.then().assertThat().statusCode(statusCode);
		System.out.println("The status code for updatestatusCode: " + statusCode);
	}
	
	@When("Delete jira issue")
	public void deleteInc()
	{
		inputRequest = RestAssured.given().contentType("application/json");
		response = inputRequest.delete(issueId);
		
	}
	@Then("The Status Code is {int}")
	public void deleteStatusCode(int statusCode)
	{
		response.then().assertThat().statusCode(statusCode);
		System.out.println("The statsu code for delete: " + statusCode);
	}
			
}
